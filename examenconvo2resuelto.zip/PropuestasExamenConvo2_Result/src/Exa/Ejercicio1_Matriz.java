package Exa;

import java.util.Scanner;

public class Ejercicio1_Matriz {

	public static void main(String[] args) {
		Scanner teclado =new Scanner(System.in);
	     int[][] mat;
	     int filas, columnas, sumaelementos=0;
	     double promedioelementos = 0, mult = 1;
do { 

	System.out.print("ingrese el numero de fila para la matriz:\n");
	filas=teclado.nextInt();
	System.out.print("ingrese el numero de columnas para la matriz:\n");
	columnas=teclado.nextInt();
	if(filas<=0 || columnas<=0) {
		System.out.println("solo numeros positivos");
	}
	
}while(filas<=0 || columnas<=0);
	   
mat=new int[filas][columnas];
System.out.println();
       for(int f=0;f<mat.length;f++) {
           for(int c=0;c<mat[f].length;c++) {
               System.out.print("Ingrese elementos a la matriz:\n ");
               mat[f][c]=teclado.nextInt();
               sumaelementos= sumaelementos+mat[f][c];
               mult=mult*mat[f][c]; 
                 
              
           }
       }
       
       promedioelementos=sumaelementos/(filas*columnas);
     
   //   
       System.out.println(" ----------------------------------");
       //mostrar la matriz
       System.out.println("Datos ingresados en la Matriz: ");
  
       for(int f=0;f<mat.length;f++) {
           for(int c=0;c<mat[f].length;c++) {
               System.out.print(" "+ mat[f][c]+",");
                
           }
           System.out.println(" ");
       }
      
       System.out.print("\n ----------------------------------");
     //imprimir mayor
   	int mayor=mat[0][0];
   	int filamay=0;
   	int columnamay=0;
       for(int f=0;f<mat.length;f++) {
           for(int c=0;c<mat[f].length;c++) {
               if (mat[f][c]>mayor) {
                   mayor=mat[f][c];
                   filamay=f;
                   columnamay=c;
               }
           }
       }
       
       //imprimir menor
   	int menor=mat[0][0];
   	int filamay1=0;
   	int columnamay1=0;
   	 System.out.println();
       for(int f=0;f<mat.length;f++) {
           for(int c=0;c<mat[f].length;c++) {
               if (mat[f][c]<menor) {
               	menor=mat[f][c];
                   filamay1=f;
                   columnamay1=c;
               }
           }
       }
    System.out.println("Resultdo de la mutli: "+ mult);
       System.out.println("La sumatoria de elementos son: "+ sumaelementos+ " y su Promedio: "+ promedioelementos+ " %");
       System.out.print("El elemento mayor es: "+mayor);
       System.out.print(" (F"+(filamay+1)+ ", C"+(columnamay+1)+"):");
       System.out.println();
       
       System.out.print("El elemento menor es: "+menor);
       System.out.print(" (F "+(filamay1+1)+ ", C"+(columnamay1+1)+"):");
       

	}

}
