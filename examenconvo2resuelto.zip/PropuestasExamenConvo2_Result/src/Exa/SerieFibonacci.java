package Exa;

import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class SerieFibonacci {

	 
		public static void main(String[] args) throws IOException {
			int suma=1, num1=0, num2=1;
			//cambiar esta direccion
			 FileWriter fichero = new FileWriter("C:\\Users\\AFCP-PC\\Videos\\convo 1 y 2 introduccion a la progra\\Convo2/ficheros.txt");
				 
			 fichero.write("el N-ésimo termino: "+SerieF()+"\n");
			 //imprimimos la secuencias
			 for (int i = 1; i < 11; i++) {             
		            // muestro la suma
		         System.out.print(", "+suma);
		           //primero sumamos
		            suma = num1 + num2;
		            
		            num1 = num2;
		            
		            num2 = suma;	             
		        }
					 
			 JOptionPane.showMessageDialog(null, "Se creo el archivo, el N-ésimo termino: será: "+SerieF());
			 
			 fichero.close();
			 
			 
			
		} 	
		
		//1, 1, 2, 3, 5, 8, 13, 21, 34,55
		public static int SerieF() {
			int serie = 10, num1 = 0, num2 = 1, suma = 1;
			 
			 for (int i = 1; i < serie; i++) {             
		            // muestro la suma
		         // System.out.print(", "+suma);
		           //primero sumamos
		            suma = num1 + num2;
		            //Despues, cambiamos la segunda variable por la primera
		            num1 = num2;
		            //Por ultimo, cambiamos la suma por la segunda variable
		            num2 = suma;	             
		        }
		     	return suma;
		     	 
			}
		
 

}
