package Exa;

import java.util.Scanner;

public class busquedaenMatriz {

	public static void main(String[] args) {
		Scanner tc = new Scanner(System.in);
		int datos;
		int matriz[][] =new int[2][2];
		  //llenamos nuestra matriz
		System.out.println("***** Una matriz de 2X2 ********");
		  for(int i=0;i<matriz.length;i++){
		   for(int j=0;j<matriz[i].length;j++){
			   System.out.println("Ingrese los elementos en la matriz en su posición ("+(i+1)+","+(j+1)+"):");
			    matriz[i][j]=tc.nextInt();
			    datos=matriz[i][j];
		    			     
		    while(datos<=0) {
		    	System.out.println("Ingrese elementos mayores a 0 en la matriz en su posición ("+(i+1)+","+(j+1)+"):");
			    matriz[i][j]=tc.nextInt();
			    datos=matriz[i][j];
		    	
		    }
			   
		   }
		  }
		System.out.println(); 
		System.out.println("---Mostrando matriz");
		  for(int i=0;i<matriz.length;i++){
		   for(int j=0;j<matriz[i].length;j++){
		    System.out.print(" "+matriz[i][j]+",");
		   }
		   System.out.println(); 
		  }
		  System.out.println();
		System.out.println("**Digite un valor a buscar---");
		int buscar = tc.nextInt();
		String coordenadas="";
		//La busqueda es de manera iterativa-Algoritmo de busqueda
		  for(int i=0;i<matriz.length;i++){
		   for(int j=0;j<matriz[i].length;j++){
		    if(matriz[i][j]==buscar){
		     coordenadas+="("+(i+1)+","+(j+1)+")"+"";
		    
		    }
		   }
		  }


		  if(coordenadas.equals("")){
		   System.out.println("El elemento buscado "+buscar+" no existe en la matriz :)");
		  }
		  else if(coordenadas.equals(coordenadas)){
			   System.out.println("El elemento buscado fué el: "+buscar+" esta en las posciciones "+coordenadas);
			  
			  }
		  else{
		   System.out.println("El elemento buscado fué el: "+buscar+" y esta en la poscicion "+coordenadas);
		  
		  }
		
		
		
		

	}

}
