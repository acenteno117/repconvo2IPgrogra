package POO;

public class Empleado extends Persona {
	private double sueldo;
	private String categoria; 
	private Departamento departamento; //asociación  
   //constructor     
	public Empleado(String dni, String nombre, 
			int edad, String estado, double sueldo, 
			String categoria, Direccion diremp1, Departamento departamento) {
		
		super(dni, nombre, edad, estado);  
		this.sueldo = sueldo;     
		this.categoria = categoria;    
		this.departamento = departamento;     
		this.departamento.altaEmpleado(this);
		//tenemos que incorporar el empleado al departamento   
		} @Override  public String toString()
			{       
			return super.toString() + " # Empleado{" + "sueldo=" + sueldo +
					", categoria=" + categoria + ", departamento=" + departamento + '}';  
			}
		
		public double sueldoNeto(int i) {
			// TODO Auto-generated method stub
			sueldo= 2000;
			return sueldo;
		}
		public void setDepartamento(Departamento departamento2) {
			// TODO Auto-generated method stub
			
		} 
	}

 
