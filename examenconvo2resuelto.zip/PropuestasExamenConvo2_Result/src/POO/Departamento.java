package POO;

import java.util.ArrayList;

public class Departamento {

	private String nombre; 
	private String id;  
	private String localizacion;    
	private Empresa empresa; //asociación, empresa en la que está el departamento 
	
	private ArrayList<Empleado> empleados; //asociación, almacena los empleados del departamento    
	
	//constructor  
	public Departamento(String nombre, String id, String localizacion, Empresa empresa) {         	this.nombre = nombre; 
	this.id = id;  
      this.localizacion = localizacion;    
      this.empresa = empresa;  
      empleados = new ArrayList<>(); //array vacío para ir añadiendo los empleados  
      empresa.altaDepartamento(this);  //añadimos el departamento a la empresa    
      }     
	//métodos get y set
 	
	 
	
	//alta de un empleado en el departamento     
	public void altaEmpleado(Empleado emp) {        
	if (!empleados.contains(emp)) 
		{   
		empleados.add(emp);   
		emp.setDepartamento(this); //el empleado tiene que reflejar el alta    
		}    
	}      
//baja de un empleado del departamento  
public void bajaEmpleado(Empleado emp) 
{     
   if (empleados.contains(emp)) 
   {           
	   empleados.remove(emp);          
	   emp.setDepartamento(null); 
	   //el empleado tiene que reflejar la baja    
	   } 
   }       
//información textual del departamento  
	
	@Override     public String toString() 
	{        
	return "Departamento{" + "nombre=" + nombre + ", id=" + id + ", localizacion=" + localizacion + ", empresa=" + empresa + '}'; 

	}
}
